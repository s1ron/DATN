import "./GlobalStyle.scss"

const GlobalStyle = ({children}) => {
     return children;
}

export default GlobalStyle