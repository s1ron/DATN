const UserProfile = () => {
  return (
    <div>UserProfile</div>
  )
}

export default UserProfile