const Friends = [
  { 
    name: 'Võ Ngọc Vũ',
    avatar: 'https://i.pinimg.com/280x280_RS/2e/45/66/2e4566fd829bcf9eb11ccdb5f252b02f.jpg',
    online: false,
    path: '/'
  },
  { 
    name: 'Ngô Thành Danh',
    avatar: 'https://i.pinimg.com/280x280_RS/2e/45/66/2e4566fd829bcf9eb11ccdb5f252b02f.jpg',
    online: false,
    path: '/'
  },
  { 
    name: 'Nguyễn Văn Tiến',
    avatar: 'https://i.pinimg.com/280x280_RS/2e/45/66/2e4566fd829bcf9eb11ccdb5f252b02f.jpg',
    online: false,
    path: '/'
  },
  { 
    name: 'Trần Tiến Đạt',
    avatar: 'https://i.pinimg.com/280x280_RS/2e/45/66/2e4566fd829bcf9eb11ccdb5f252b02f.jpg',
    online: false,
    path: '/'
  },
  { 
    name: 'John',
    avatar: 'https://i.pinimg.com/280x280_RS/2e/45/66/2e4566fd829bcf9eb11ccdb5f252b02f.jpg',
    online: false,
    path: '/'
  }
]


export default Friends