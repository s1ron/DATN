const Store = [
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp3KkKgrgsKm4OZvKdal8MQA6QsZOW20hNxzxCx2r0yU1qB2ctEuoGaEf0LZWxRrkKwk8&usqp=CAU"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg"
  },
  {
    img: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg",
    author: "Võ Ngọc Vũ",
    avatar: "https://static-images.vnncdn.net/files/publish/2022/9/3/bien-vo-cuc-thai-binh-346.jpeg"
  },
];

export default Store