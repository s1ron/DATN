const Notification = () => {
  return (
    <div>Notification</div>
  )
}

export default Notification